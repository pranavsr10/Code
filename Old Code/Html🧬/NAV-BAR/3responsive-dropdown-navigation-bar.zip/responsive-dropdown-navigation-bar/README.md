# Responsive Dropdown Navigation Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/taniarascia/pen/dYvvYv](https://codepen.io/taniarascia/pen/dYvvYv).

A responsive dropdown navbar with animated hamburger menu icon. Built with Sass.